<!DOCTYPE HTML>
    <html>
        <body>
        <h1>
            Welcome <?php echo $_POST["username"]; ?><br>
            Your password is: <?php echo $_POST["password"]; ?>
        </h1>
        </body>
    </html>
