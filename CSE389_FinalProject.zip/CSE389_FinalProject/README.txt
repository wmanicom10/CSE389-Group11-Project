Our project runs on php, html, and utilizes the firebase database.

To ensure everything runs correctly, make sure XAMPP and Composer is installed.

After both are installed, go into C:->xampp->htdocs and unzip the zip file and place the folder in the htdocs folder.

After that, run XAMPP and click "start" on Apache.

Type in http://localhost/CSE389_FinalProject/index.html into the browser of your choice to get to the first screen. 

To try and login on the user login page, you can either create a new account or login with:
Username: Dane
Password: 111

When creating a new username, make sure to NOT include any hyphens ("-") as this will cause the program to split the string
incorrectly.

To try and login on the admin login page, there is not currently a way to add new admins other than to manually go into the
database and add it. To test the admin login page, login with:
Username: chris
Password: 83